# -*- coding: utf-8 -*-
from __future__ import print_function, unicode_literals

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigSelection, ConfigText, getConfigListEntry
from Components.Sources.StaticText import StaticText
from Components.Button import Button
from Screens.MessageBox import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.ChoiceBox import ChoiceBox
from enigma import eConsoleAppContainer, eTimer, ePoint, gRGB, eSize
import os
import json
import base64
import time
import struct
import array
import math
import re
import random
from colorsys import hls_to_rgb

PLUGIN_ICON = 'plugin.png'
PLUGIN_VERSION = '2.8'

API_KEY_PATHS = {
    'groq': '/etc/enigma2/groq_api_key.txt',
    'gemini': '/etc/enigma2/gemini_api_key.txt'
}

# New config section
config.plugins.AiTranslateS = ConfigSubsection()
config.plugins.AiTranslateS.enabled = ConfigSelection(default='false', choices=[('false', 'Disabled'), ('true', 'Enabled')])
config.plugins.AiTranslateS.provider = ConfigSelection(default='auto', choices=[('auto', 'Auto (Groq->Gemini)'), ('groq', 'Groq Only'), ('gemini', 'Gemini Only')])
config.plugins.AiTranslateS.font_size = ConfigSelection(default='52', choices=[('36', '36'), ('42', '42'), ('48', '48'), ('52', '52'), ('56', '56'), ('60', '60')])
config.plugins.AiTranslateS.max_words = ConfigSelection(default='10', choices=[('8', '8 words'), ('10', '10 words'), ('12', '12 words'), ('15', '15 words'), ('20', '20 words')])
config.plugins.AiTranslateS.color_mode = ConfigSelection(default='random', choices=[('random', 'Random colors'), ('sequential', 'Sequential colors'), ('fixed', 'Fixed color'), ('gradient', 'Gradient colors')])
config.plugins.AiTranslateS.fixed_color = ConfigSelection(default='#ffff00', choices=[
    ('#ffff00', 'Yellow'), ('#00ff00', 'Green'), ('#00aaff', 'Light Blue'),
    ('#ff00ff', 'Pink'), ('#ff8800', 'Orange'), ('#ff0000', 'Red'),
    ('#aa00ff', 'Purple'), ('#00ffff', 'Cyan')
])

def safe_makedirs(path):
    try:
        os.makedirs(path)
    except OSError as e:
        if e.errno != 17:  # not already exists
            raise

class APIKeyManager:
    @staticmethod
    def read_api_key(provider):
        file_path = API_KEY_PATHS.get(provider)
        if not file_path:
            return ''
        try:
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    return f.read().strip()
            else:
                # create empty file
                safe_makedirs(os.path.dirname(file_path))
                with open(file_path, 'w') as f:
                    f.write('')
                return ''
        except Exception as e:
            print('[AiTranslateS] Error reading {} API key: {}'.format(provider, e))
            return ''

    @staticmethod
    def write_api_key(provider, api_key):
        file_path = API_KEY_PATHS.get(provider)
        if not file_path:
            return False
        try:
            safe_makedirs(os.path.dirname(file_path))
            with open(file_path, 'w') as f:
                f.write(api_key.strip())
            return True
        except Exception as e:
            print('[AiTranslateS] Error writing {} API key: {}'.format(provider, e))
            return False

    @staticmethod
    def get_api_keys():
        return {
            'groq': APIKeyManager.read_api_key('groq'),
            'gemini': APIKeyManager.read_api_key('gemini')
        }

    @staticmethod
    def validate_api_key(provider, api_key):
        if not api_key or not isinstance(api_key, str):
            return False
        if provider == 'groq':
            return api_key.startswith('gsk_') and len(api_key) > 20
        elif provider == 'gemini':
            return api_key.startswith('AIza') and len(api_key) > 30
        else:
            return True

class ColorManager:
    COLOR_PALETTES = {
        'vibrant': ['#FF6B6B', '#4ECDC4', '#FFD166', '#06D6A0', '#118AB2', '#EF476F', '#26547C', '#FFD166', '#06D6A0', '#073B4C'],
        'pastel': ['#FFB3BA', '#BAFFC9', '#BAE1FF', '#FFFFBA', '#FFDFBA', '#E6E6FA', '#D8BFD8', '#B0E0E6', '#98FB98', '#FFDAB9'],
        'warm': ['#FF7F50', '#FF6347', '#FF4500', '#FF8C00', '#FFA500', '#FFD700', '#B8860B', '#DAA520', '#CD853F', '#8B4513'],
        'cool': ['#87CEEB', '#4682B4', '#5F9EA0', '#6495ED', '#7B68EE', '#6A5ACD', '#483D8B', '#40E0D0', '#00CED1', '#20B2AA'],
        'rainbow': ['#FF0000', '#FF7F00', '#FFFF00', '#00FF00', '#0000FF', '#4B0082', '#9400D3', '#FF1493', '#00FFFF', '#FFD700']
    }

    @staticmethod
    def hex_to_gRGB(hex_color):
        hex_color = hex_color.lstrip('#')
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        return gRGB(r << 16 | g << 8 | b)

    @staticmethod
    def get_random_color(palette_name='vibrant'):
        palette = ColorManager.COLOR_PALETTES.get(palette_name, ColorManager.COLOR_PALETTES['vibrant'])
        return random.choice(palette)

    @staticmethod
    def get_sequential_color(index, palette_name='vibrant'):
        palette = ColorManager.COLOR_PALETTES.get(palette_name, ColorManager.COLOR_PALETTES['vibrant'])
        return palette[index % len(palette)]

    @staticmethod
    def get_gradient_color(text, base_color='#ffff00'):
        # simple gradient based on text hash
        text_hash = hash(text) % 360
        hue = text_hash
        lightness = 80 + (hash(text) % 20)
        saturation = 50 + (hash(text[::-1]) % 20)
        r, g, b = hls_to_rgb(hue / 360.0, lightness / 100.0, saturation / 100.0)
        return '#{:02x}{:02x}{:02x}'.format(int(r * 255), int(g * 255), int(b * 255))

class AiTranslateOverlay(Screen):
    skin_template = '''<?xml version="1.0" encoding="UTF-8"?>
<screen name="AiTranslateOverlay" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent" zPosition="10">
    <!-- Shadow behind subtitle text (initially hidden) -->
    <widget name="shadow" position="45,850" size="1840,180" backgroundColor="#80000000" zPosition="5" />
    <!-- Main subtitle label -->
    <widget name="subtitles" position="50,820" size="1820,250" font="Regular;%s" halign="center" valign="center" foregroundColor="#ffff00" backgroundColor="#80000000" transparent="1" zPosition="10" />
    <!-- Status labels -->
    <widget name="status" position="5,5" size="200,35" font="Regular;18" foregroundColor="#00ff00" backgroundColor="#80000000" zPosition="10" />
    <widget name="provider" position="5,45" size="200,35" font="Regular;18" foregroundColor="#00aaff" backgroundColor="#80000000" zPosition="10" />
    <widget name="color_indicator" position="5,85" size="200,35" font="Regular;18" foregroundColor="#ffffff" backgroundColor="#80000000" zPosition="10" />
</screen>'''

    STAGE_IDLE = 0
    STAGE_DOWNLOAD = 1
    STAGE_TRANSCRIBE = 2
    STAGE_TRANSLATE = 3
    STAGE_GEMINI = 4

    CAPTURE_DURATION = 6
    RESTART_DELAY = 2000

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self.font_size = config.plugins.AiTranslateS.font_size.value
        self.max_words = int(config.plugins.AiTranslateS.max_words.value)
        self.color_mode = config.plugins.AiTranslateS.color_mode.value
        self.fixed_color = config.plugins.AiTranslateS.fixed_color.value

        self.skin = AiTranslateOverlay.skin_template % self.font_size

        self['subtitles'] = Label('')
        self['status'] = Label('Initializing...')
        self['provider'] = Label('')
        self['color_indicator'] = Label('')
        self['shadow'] = Label('')

        self.console = eConsoleAppContainer()
        self.console.appClosed.append(self.onProcessFinished)
        self.console.dataAvail.append(self.onConsoleData)

        self.stage = self.STAGE_IDLE
        self.api_key_groq = APIKeyManager.read_api_key('groq')
        self.api_key_gemini = APIKeyManager.read_api_key('gemini')
        self.provider_mode = config.plugins.AiTranslateS.provider.value
        self.current_provider = 'groq'
        self.color_index = 0
        self.previous_text = ''
        self.current_color = self.fixed_color
        self.wav_path = '/tmp/ai_capture.wav'
        self.raw_path = '/tmp/ai_raw.pcm'
        self.shadow_visible = False
        self['shadow'].hide()

        self.capture_timer = None
        self.kill_timer = None
        self.retry_timer = None
        self.loop_timer = None
        self.stop_process_timer = None

        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {
            'cancel': self.close,
            'exit': self.close,
            'red': self.close,
            'green': self.changeColorMode,
            'yellow': self.forceRefresh,
            'blue': self.toggleColorPreview,
            '0': self.toggleShadow
        }, -2)

        # Immediately hide status labels (user request)
        self.hideStatusLabels(True)

        if not self.check_gst_available():
            self['status'].setText('Error: gst-launch-1.0 not found')
            self['provider'].setText('')
        else:
            self.onLayoutFinish.append(self.startCycle)

    def toggleShadow(self):
        self.shadow_visible = not self.shadow_visible
        if self.shadow_visible:
            self['shadow'].show()
        else:
            self['shadow'].hide()
        # briefly show status to confirm
        if hasattr(self, 'shadow_status_timer') and self.shadow_status_timer:
            self.shadow_status_timer.stop()
        self.shadow_status_timer = eTimer()
        self.shadow_status_timer.callback.append(lambda: self['status'].setText('Live' if self.stage == self.STAGE_IDLE else 'Working...'))
        self.shadow_status_timer.start(2000, True)

    def hideStatusLabels(self, hide=True):
        if hide:
            self['status'].hide()
            self['provider'].hide()
            self['color_indicator'].hide()
        else:
            self['status'].show()
            self['provider'].show()
            self['color_indicator'].show()

    def check_gst_available(self):
        try:
            import subprocess
            with open(os.devnull, 'w') as devnull:
                ret = subprocess.call(['which', 'gst-launch-1.0'], stdout=devnull, stderr=devnull)
                return ret == 0
        except:
            return False

    def forceRefresh(self):
        self['status'].setText('Forced refresh...')
        self.stop_current_process()
        self.startCycle()

    def stop_current_process(self):
        try:
            self.console.sendCtrlC()
        except:
            pass
        if self.stop_process_timer:
            self.stop_process_timer.stop()
        self.stop_process_timer = eTimer()
        self.stop_process_timer.callback.append(self.force_kill_process)
        self.stop_process_timer.start(500, True)

    def force_kill_process(self):
        try:
            self.console.kill()
        except:
            pass

    def _stop_all_timers(self):
        for timer_name in ['capture_timer', 'kill_timer', 'retry_timer', 'loop_timer', 'stop_process_timer']:
            timer = getattr(self, timer_name, None)
            if timer:
                timer.stop()
                setattr(self, timer_name, None)

    def get_next_color(self, text):
        if self.color_mode == 'fixed':
            return self.fixed_color
        elif self.color_mode == 'random':
            return ColorManager.get_random_color('vibrant')
        elif self.color_mode == 'sequential':
            color = ColorManager.get_sequential_color(self.color_index, 'vibrant')
            self.color_index += 1
            return color
        elif self.color_mode == 'gradient':
            return ColorManager.get_gradient_color(text)
        else:
            return '#ffff00'

    def update_color_indicator(self):
        color_mode_names = {
            'random': 'Random',
            'sequential': 'Sequential',
            'fixed': 'Fixed',
            'gradient': 'Gradient'
        }
        mode_name = color_mode_names.get(self.color_mode, 'Unknown')
        self['color_indicator'].setText('Color: {}'.format(mode_name))

    def changeColorMode(self):
        choices = [
            ('Random colors', 'random'),
            ('Sequential colors', 'sequential'),
            ('Fixed color', 'fixed'),
            ('Gradient colors', 'gradient')
        ]
        self.session.openWithCallback(self.colorModeChanged, ChoiceBox, title='Select color mode:', list=choices)

    def colorModeChanged(self, result):
        if result:
            self.color_mode = result[1]
            config.plugins.AiTranslateS.color_mode.value = result[1]
            config.plugins.AiTranslateS.color_mode.save()
            self.update_color_indicator()

    def toggleColorPreview(self):
        preview_text = 'This is a sample of different colors'
        colors = ColorManager.COLOR_PALETTES['vibrant']
        self['subtitles'].setText(preview_text)
        self['status'].setText('Color preview')
        self.preview_index = 0
        self.preview_colors = colors

        def next_preview_color():
            if self.preview_index < len(self.preview_colors):
                color = self.preview_colors[self.preview_index]
                grgb_color = ColorManager.hex_to_gRGB(color)
                self['subtitles'].instance.setForegroundColor(grgb_color)
                self['color_indicator'].setText('Preview: {}'.format(color))
                self.preview_index += 1
                self.preview_timer.start(1000, True)
            else:
                self.preview_timer.stop()
                self.update_color_indicator()
                if self.previous_text:
                    self['subtitles'].setText(self.previous_text)
                    grgb_color = ColorManager.hex_to_gRGB(self.current_color)
                    self['subtitles'].instance.setForegroundColor(grgb_color)
                else:
                    self['subtitles'].setText('')
                self['status'].setText('Live')

        self.preview_timer = eTimer()
        self.preview_timer.callback.append(next_preview_color)
        next_preview_color()

    def onConsoleData(self, data):
        try:
            print('[AiTranslateS Console]', data.decode('utf-8', errors='ignore'))
        except:
            pass

    def startCycle(self):
        self.api_key_groq = APIKeyManager.read_api_key('groq')
        self.api_key_gemini = APIKeyManager.read_api_key('gemini')

        # Determine provider
        if self.provider_mode == 'auto':
            if self.api_key_groq and APIKeyManager.validate_api_key('groq', self.api_key_groq):
                self.current_provider = 'groq'
            elif self.api_key_gemini and APIKeyManager.validate_api_key('gemini', self.api_key_gemini):
                self.current_provider = 'gemini'
                self.provider_mode = 'gemini'
            else:
                self['status'].setText('No valid API keys')
                self['provider'].setText('')
                self.close()
                return
        else:
            self.current_provider = self.provider_mode
            if self.current_provider == 'groq' and not (self.api_key_groq and APIKeyManager.validate_api_key('groq', self.api_key_groq)):
                self['status'].setText('Groq API key missing or invalid')
                self['provider'].setText('')
                self.close()
                return
            elif self.current_provider == 'gemini' and not (self.api_key_gemini and APIKeyManager.validate_api_key('gemini', self.api_key_gemini)):
                self['status'].setText('Gemini API key missing or invalid')
                self['provider'].setText('')
                self.close()
                return

        self['provider'].setText(self.current_provider.upper())
        self['status'].setText('Live')
        self.update_color_indicator()
        # Status labels are already hidden from __init__, so no show call here
        self.startCapture()

    def extractIptvUrl(self, sref_str):
        parts = sref_str.split(':')
        if len(parts) >= 10:
            url_part = ':'.join(parts[10:])
            if url_part:
                try:
                    from urllib.parse import unquote
                except ImportError:
                    from urllib import unquote
                stream_url = unquote(url_part)
                # Try to extract a direct stream URL
                match = re.search(r'(https?://[^\s]+\.(?:ts|m3u8|flv|mp4|mkv)[^\s]*)', stream_url)
                if match:
                    return match.group(1)
                # Fallback: take first part before space
                if ' ' in stream_url:
                    stream_url = stream_url.split(' ')[0]
                if stream_url.startswith('http'):
                    return stream_url
        return None

    def startCapture(self):
        self.stage = self.STAGE_DOWNLOAD
        sref = self.session.nav.getCurrentlyPlayingServiceReference()
        if not sref:
            self['status'].setText('No service')
            self.scheduleRetry(2000)
            return
        sref_str = sref.toString()
        is_iptv = sref_str.startswith('4097:') or sref_str.startswith('5001:') or sref_str.startswith('5002:') or sref_str.startswith('8193:')

        # Remove old files
        for path in [self.wav_path, self.raw_path]:
            try:
                if os.path.exists(path):
                    os.remove(path)
            except:
                pass

        if is_iptv:
            self['status'].setText('Recording (IPTV)...')
            stream_url = self.extractIptvUrl(sref_str)
            if stream_url:
                with open('/tmp/ai_iptv_url.log', 'w') as f:
                    f.write(stream_url)
                cmd = 'timeout {} gst-launch-1.0 -q souphttpsrc location="{}" ! decodebin ! audioconvert ! audioresample ! audio/x-raw,rate=16000,channels=1,format=S16LE ! filesink location="{}"'.format(
                    self.CAPTURE_DURATION, stream_url, self.raw_path)
            else:
                self['status'].setText('Error: No URL')
                self.scheduleRetry(2000)
                return
        else:
            self['status'].setText('Recording (DVB)...')
            url = 'http://127.0.0.1:8001/' + sref_str
            cmd = 'timeout {} gst-launch-1.0 -q souphttpsrc location="{}" ! decodebin ! audioconvert ! audioresample ! audio/x-raw,rate=16000,channels=1,format=S16LE ! filesink location="{}"'.format(
                self.CAPTURE_DURATION, url, self.raw_path)

        print('[AiTranslateS] Executing:', cmd)
        self.console.execute(cmd)
        self._stop_all_timers()
        self.capture_timer = eTimer()
        self.capture_timer.callback.append(self.stopCapturePipe)
        self.capture_timer.start(self.CAPTURE_DURATION * 1000 + 1000, True)

    def stopCapturePipe(self):
        try:
            self.console.sendCtrlC()
        except:
            pass
        self.kill_timer = eTimer()
        self.kill_timer.callback.append(self.forceFinish)
        self.kill_timer.start(1500, True)

    def forceFinish(self):
        try:
            self.console.kill()
        except:
            pass
        self.onProcessFinished(0)

    def writeWavHeader(self, raw_path, wav_path):
        try:
            with open(raw_path, 'rb') as inp:
                audio_data = inp.read()
            data_size = len(audio_data)
            if data_size < 32000:
                print('[AiTranslateS] Audio too short: {} bytes'.format(data_size))
                return False
            with open(wav_path, 'wb') as out:
                out.write(b'RIFF')
                out.write(struct.pack('<I', data_size + 36))
                out.write(b'WAVE')
                out.write(b'fmt ')
                out.write(struct.pack('<I', 16))
                out.write(struct.pack('<H', 1))          # PCM
                out.write(struct.pack('<H', 1))          # mono
                out.write(struct.pack('<I', 16000))       # sample rate
                out.write(struct.pack('<I', 32000))       # byte rate
                out.write(struct.pack('<H', 2))           # block align
                out.write(struct.pack('<H', 16))          # bits per sample
                out.write(b'data')
                out.write(struct.pack('<I', data_size))
                out.write(audio_data)
            return True
        except Exception as e:
            print('[AiTranslateS] Error writing WAV header:', e)
            return False

    def is_silent(self, wav_path, threshold=500):
        try:
            import wave
            wf = wave.open(wav_path, 'rb')
            if wf.getnchannels() != 1 or wf.getsampwidth() != 2 or wf.getframerate() != 16000:
                wf.close()
                return True
            frames = wf.readframes(wf.getnframes())
            wf.close()
            samples = array.array('h', frames)
            if len(samples) == 0:
                return True
            squares = sum(sample * sample for sample in samples)
            rms = math.sqrt(squares / len(samples))
            return rms < threshold
        except Exception as e:
            print('[AiTranslateS] Error checking silence:', e)
            return True

    def truncate_text(self, text):
        if not text:
            return ''
        words = text.split()
        if len(words) > self.max_words:
            return ' '.join(words[:self.max_words]) + ' ...'
        return text

    def clean_text(self, text):
        if not text:
            return ''
        text = text.strip('"\'')
        # Allow Arabic and common punctuation
        cleaned = re.sub(r'[^\u0600-\u06FFa-zA-Z0-9\s\.\,\?\!\-]', '', text)
        return cleaned.strip()

    def onProcessFinished(self, retval):
        self._stop_all_timers()
        if self.stage == self.STAGE_DOWNLOAD:
            if not os.path.exists(self.raw_path) or os.path.getsize(self.raw_path) < 5000:
                self['status'].setText('Error: Recording too short')
                self.scheduleRetry(2000)
                return
            if not self.writeWavHeader(self.raw_path, self.wav_path):
                self['status'].setText('Error: WAV')
                self.scheduleRetry(2000)
                return
            try:
                os.remove(self.raw_path)
            except:
                pass
            if self.is_silent(self.wav_path):
                self['status'].setText('No speech detected')
                self.restartLoop()
            else:
                self.stage = self.STAGE_TRANSCRIBE
                if self.current_provider == 'gemini':
                    self.doGeminiProcess()
                else:
                    self.doGroqTranscribe()
        elif self.stage == self.STAGE_TRANSCRIBE:
            if self.current_provider == 'groq':
                self.doGroqTranslate()
            else:
                self.showResultGemini()
        elif self.stage == self.STAGE_TRANSLATE:
            self.showResult()
        elif self.stage == self.STAGE_GEMINI:
            self.showResultGemini()

    def doGroqTranscribe(self):
        self.stage = self.STAGE_TRANSCRIBE
        self['status'].setText('Transcribing...')
        if not self.api_key_groq.startswith('gsk_'):
            self.handleFail('Invalid Groq API key')
            return
        url = 'https://api.groq.com/openai/v1/audio/transcriptions'
        cmd = 'curl -k -s --max-time 30 -X POST "{}" -H "Authorization: Bearer {}" -F "file=@{}" -F "model=whisper-large-v3" -F "response_format=json" -o /tmp/groq_transcribe.json'.format(
            url, self.api_key_groq.strip(), self.wav_path)
        print('[AiTranslateS] Transcribing with Groq...')
        self.console.execute(cmd)

    def doGeminiProcess(self):
        self.stage = self.STAGE_GEMINI
        self['status'].setText('Processing with Gemini...')
        if not self.api_key_gemini:
            self['status'].setText('No Gemini API key!')
            self.scheduleRetry(3000)
            return
        try:
            with open(self.wav_path, 'rb') as wav_file:
                b64_audio = base64.b64encode(wav_file.read()).decode('utf-8')
            url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=' + self.api_key_gemini.strip()
            prompt_text = 'Listen to this audio, transcribe it, and translate it to Arabic. Maximum {} words. Return ONLY the Arabic translation. If no speech, return "no_speech".'.format(self.max_words)
            payload = {
                'contents': [{
                    'parts': [
                        {'text': prompt_text},
                        {'inline_data': {'mime_type': 'audio/wav', 'data': b64_audio}}
                    ]
                }]
            }
            with open('/tmp/gemini_payload.json', 'w') as f:
                json.dump(payload, f)
            cmd = 'curl -k -s --max-time 30 -X POST "{}" -H "Content-Type: application/json" -d @/tmp/gemini_payload.json -o /tmp/gemini_result.json'.format(url)
            print('[AiTranslateS] Processing with Gemini...')
            self.console.execute(cmd)
        except Exception as e:
            print('[AiTranslateS] Error in Gemini process:', e)
            self.handleFail('Failed to read file')

    def doGroqTranslate(self):
        self.stage = self.STAGE_TRANSLATE
        self['status'].setText('Translating...')
        try:
            with open('/tmp/groq_transcribe.json', 'r') as f:
                data = json.load(f)
            text = data.get('text', '').strip()
            if not text or len(text) < 2 or text.lower() in ['no_speech', 'none', '']:
                if self.provider_mode == 'auto' and self.current_provider == 'groq':
                    self.current_provider = 'gemini'
                    self['status'].setText('Switching to Gemini')
                    self.doGeminiProcess()
                else:
                    self['status'].setText('No speech detected')
                    self.restartLoop()
            else:
                url = 'https://api.groq.com/openai/v1/chat/completions'
                prompt = 'Translate this text to Arabic. Maximum {} words. Return ONLY the translation: {}'.format(self.max_words, text)
                payload = {
                    'model': 'llama-3.1-8b-instant',
                    'messages': [{'role': 'user', 'content': prompt}],
                    'max_tokens': 100
                }
                with open('/tmp/groq_payload.json', 'w') as f:
                    json.dump(payload, f)
                cmd = 'curl -k -s --max-time 20 -X POST "{}" -H "Authorization: Bearer {}" -H "Content-Type: application/json" -d @/tmp/groq_payload.json -o /tmp/groq_translate.json'.format(
                    url, self.api_key_groq)
                print('[AiTranslateS] Translating with Groq...')
                self.console.execute(cmd)
        except Exception as e:
            print('[AiTranslateS] Error in translation:', e)
            self.handleFail('Translation error')

    def showResultGemini(self):
        self.stage = self.STAGE_IDLE
        try:
            if os.path.exists('/tmp/gemini_result.json'):
                with open('/tmp/gemini_result.json', 'r') as f:
                    response = json.load(f)
                content = ''
                if 'candidates' in response and len(response['candidates']) > 0:
                    candidate = response['candidates'][0]
                    if 'content' in candidate and 'parts' in candidate['content']:
                        parts = candidate['content']['parts']
                        if parts and 'text' in parts[0]:
                            content = parts[0]['text'].strip()
                if content:
                    if content.lower() != 'no_speech':
                        content = self.clean_text(content)
                        if content:
                            content = self.truncate_text(content)
                            self.current_color = self.get_next_color(content)
                            grgb_color = ColorManager.hex_to_gRGB(self.current_color)
                            self['subtitles'].instance.setForegroundColor(grgb_color)
                            self['subtitles'].setText(content)
                            self.update_color_indicator()
                            self['status'].setText('')
                            self.previous_text = content
                            self.hideStatusLabels(True)
                        else:
                            self['status'].setText('Empty text after cleaning')
                    else:
                        self['status'].setText('No speech detected')
                else:
                    self['status'].setText('No response from Gemini')
            else:
                self['status'].setText('No response from Gemini')
        except Exception as e:
            print('[AiTranslateS] Error showing Gemini result:', e)
            self['status'].setText('Gemini error')
        self.restartLoop()

    def showResult(self):
        self.stage = self.STAGE_IDLE
        try:
            if os.path.exists('/tmp/groq_translate.json'):
                with open('/tmp/groq_translate.json', 'r') as f:
                    response = json.load(f)
                content = ''
                if 'choices' in response and len(response['choices']) > 0:
                    choice = response['choices'][0]
                    if 'message' in choice and 'content' in choice['message']:
                        content = choice['message']['content'].strip()
                if content:
                    content = self.clean_text(content)
                    if content:
                        content = self.truncate_text(content)
                        self.current_color = self.get_next_color(content)
                        grgb_color = ColorManager.hex_to_gRGB(self.current_color)
                        self['subtitles'].instance.setForegroundColor(grgb_color)
                        self['subtitles'].setText(content)
                        self.update_color_indicator()
                        self['status'].setText('')
                        self.previous_text = content
                        self.hideStatusLabels(True)
                    else:
                        self['status'].setText('Empty text after cleaning')
                else:
                    self['status'].setText('No result')
            else:
                self['status'].setText('No response from Groq')
        except Exception as e:
            print('[AiTranslateS] Error showing result:', e)
            self['status'].setText('Error')
        self.restartLoop()

    def scheduleRetry(self, delay):
        self._stop_all_timers()
        self.stop_current_process()
        self.retry_timer = eTimer()
        self.retry_timer.callback.append(self.startCycle)
        self.retry_timer.start(delay, True)

    def restartLoop(self):
        self._stop_all_timers()
        self.stop_current_process()
        self.loop_timer = eTimer()
        self.loop_timer.callback.append(self.startCycle)
        self.loop_timer.start(self.RESTART_DELAY, True)

    def handleFail(self, msg):
        self['status'].setText(msg)
        if self.provider_mode == 'auto' and self.current_provider == 'groq':
            self['status'].setText(msg + ' -> Gemini')
            self.current_provider = 'gemini'
            self.doGeminiProcess()
        else:
            self.scheduleRetry(3000)

    def close(self):
        try:
            self.console.sendCtrlC()
        except:
            pass
        self._stop_all_timers()
        self.stop_current_process()
        temp_files = [
            self.wav_path, self.raw_path,
            '/tmp/groq_transcribe.json', '/tmp/groq_translate.json',
            '/tmp/gemini_result.json', '/tmp/gemini_payload.json',
            '/tmp/groq_payload.json'
        ]
        for f in temp_files:
            try:
                if os.path.exists(f):
                    os.remove(f)
            except:
                pass
        Screen.close(self)

class AiTranslateGridSettings(Screen):
    skin = '''
    <screen name="AiTranslateGridSettings" position="center,center" size="1400,671" title="AI TranslateS Settings v2.8 - GRID MODE" backgroundColor="background4" flags="wfNoBorder">
  <!-- Title -->
  <widget source="title" render="Label" position="316,15" size="700,50" font="Regular;30" halign="center" valign="center" backgroundColor="#101010" transparent="1" foregroundColor="#fffffe" />
  <!-- GRID CONTAINER -->
  <!-- Column Headers -->
  <widget name="col1_header" position="120,85" size="300,40" font="Regular;26" halign="center" valign="center" foregroundColor="green" backgroundColor="#40000000" transparent="1" />
  <widget name="col2_header" position="530,85" size="300,40" font="Regular;26" halign="center" valign="center" foregroundColor="#bab329" backgroundColor="#40000000" transparent="1" />
  <widget name="col3_header" position="940,85" size="300,40" font="Regular;26" halign="center" valign="center" foregroundColor="#92f1fc" backgroundColor="#40000000" transparent="1" />
  <!-- GRID CELLS - Row 1 -->
  <widget name="cell_0_0" position="130,155" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
  <widget name="cell_0_1" position="540,155" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
  <widget name="cell_0_2" position="950,155" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
  <!-- Row 2 -->
  <widget name="cell_1_0" position="130,245" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
  <widget name="cell_1_1" position="540,245" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
  <widget name="cell_1_2" position="950,245" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
  <!-- Row 3 -->
  <widget name="cell_2_0" position="130,335" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
  <widget name="cell_2_1" position="540,335" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
  <widget name="cell_2_2" position="950,335" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
  <!-- Row 4 -->
  <widget name="cell_3_0" position="130,425" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
  <widget name="cell_3_1" position="540,425" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
  <widget name="cell_3_2" position="950,425" size="280,69" font="Regular;22" halign="left" valign="center" zPosition="2" foregroundColor="white" backgroundColor="#303030" transparent="1" />
  <!-- Selection Highlight -->
  <widget name="selection_highlight" position="120,150" size="300,76" zPosition="1" backgroundColor="#800000" borderWidth="1" borderColor="white" transparent="0" />
  <!-- Navigation Help -->
  <widget name="help_text" position="60,525" size="1280,40" font="Regular; 24" halign="center" valign="center" zPosition="2" foregroundColor="green" backgroundColor="background90" />
  <!-- Footer Buttons -->
  <widget name="key_red" position="250,590" size="210,50" zPosition="1" font="Regular;24" halign="center" valign="center" backgroundColor="background90" />
  <widget name="key_green" position="490,590" size="210,50" zPosition="1" font="Regular;24" halign="center" valign="center" backgroundColor="background90" foregroundColor="white" />
  <widget name="key_yellow" position="730,590" size="210,50" zPosition="1" font="Regular;24" halign="center" valign="center" backgroundColor="background90" foregroundColor="white" />
  <widget name="key_blue" position="970,590" size="210,50" zPosition="1" font="Regular;24" halign="center" valign="center" backgroundColor="background90" foregroundColor="white" />
  <!-- Time & Date -->
  <widget source="global.CurrentTime" render="Label" position="1170,10" size="180,35" font="Regular;22" halign="center" foregroundColor="#b8860b" backgroundColor="#160000" transparent="1" zPosition="6">
    <convert type="ClockToText">Format %H:%M:%S</convert>
  </widget>
  <widget source="global.CurrentTime" render="Label" position="1175,40" size="180,35" font="Regular;24" halign="center" foregroundColor="#b8860b" backgroundColor="#160000" transparent="1" zPosition="6">
    <convert type="ClockToText">Format:%d.%m.%Y</convert>
  </widget>
  <!-- Background boxes -->
  <eLabel position="120,150" size="300,80" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#b0b0b0" foregroundColor="black" noWrap="1" />
  <eLabel position="120,240" size="300,80" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#b0b0b0" foregroundColor="black" noWrap="1" />
  <eLabel position="120,330" size="300,80" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#b0b0b0" foregroundColor="black" noWrap="1" />
  <eLabel position="120,420" size="300,80" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#9a9a9a" foregroundColor="black" noWrap="1" />
  <eLabel position="530,150" size="300,80" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#9a9a9a" foregroundColor="black" />
  <eLabel position="530,330" size="300,80" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#9a9a9a" foregroundColor="black" />
  <eLabel position="530,240" size="300,80" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#9a9a9a" foregroundColor="black" />
  <eLabel position="530,420" size="300,80" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#9a9a9a" foregroundColor="black" />
  <eLabel position="940,150" size="300,80" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#9a9a9a" foregroundColor="black" />
  <eLabel position="940,330" size="300,80" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#9a9a9a" foregroundColor="black" />
  <eLabel position="940,240" size="300,80" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#9a9a9a" foregroundColor="black" />
  <eLabel position="940,420" size="300,80" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#9a9a9a" foregroundColor="black" />
  <eLabel position="940,330" size="300,80" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#9a9a9a" foregroundColor="black" />
  <eLabel position="120,90" size="300,40" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#7fff00" foregroundColor="black" />
  <eLabel position="530,90" size="300,40" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#bab329" foregroundColor="black" />
  <eLabel position="940,90" size="300,40" zPosition="-1" backgroundColor="black" borderWidth="1" borderColor="#92f1fc" foregroundColor="black" />
  <!-- colored separator lines -->
  <eLabel backgroundColor="#fefb03" position="718,590" size="5,50" zPosition="11" />
  <eLabel backgroundColor="#1818b4" position="958,590" size="5,50" zPosition="11" />
  <eLabel backgroundColor="#8000" position="478,590" size="5,50" zPosition="11" />
  <eLabel backgroundColor="#9f1313" position="238,590" size="5,50" zPosition="11" />
  <!-- background images with updated path -->
  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AiTranslateS/images/bac.png" position="60,137" size="1280,377" zPosition="-1" transparent="1" />
  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AiTranslateS/images/ai.png" position="1027,15" size="110,50" zPosition="-1" transparent="1" />
  <eLabel position="0,575" size="1400,2" backgroundColor="#ff9800" zPosition="3" />
  <eLabel position="0,80" size="1400,2" backgroundColor="#ff9800" zPosition="3" />
</screen>
    '''

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.rows = 4
        self.cols = 3
        self.current_row = 0
        self.current_col = 0

        # Define grid content: each cell: (label, key, type, action_data)
        self.grid_content = [
            # Row 0
            [
                ('Service Provider', 'provider', 'choice', {
                    'title': 'Select Service Provider',
                    'choices': [('Auto (Groq->Gemini)', 'auto'), ('Groq only', 'groq'), ('Gemini only', 'gemini')],
                    'config': config.plugins.AiTranslateS.provider
                }),
                ('Font Size', 'font_size', 'choice', {
                    'title': 'Select Font Size',
                    'choices': [('36', '36'), ('42', '42'), ('48', '48'), ('52', '52'), ('56', '56'), ('60', '60')],
                    'config': config.plugins.AiTranslateS.font_size
                }),
                ('Max Words', 'max_words', 'choice', {
                    'title': 'Maximum Words',
                    'choices': [('8 words', '8'), ('10 words', '10'), ('12 words', '12'), ('15 words', '15'), ('20 words', '20')],
                    'config': config.plugins.AiTranslateS.max_words
                })
            ],
            # Row 1
            [
                ('Color Mode', 'color_mode', 'choice', {
                    'title': 'Select Color Mode',
                    'choices': [('Random colors', 'random'), ('Sequential colors', 'sequential'), ('Fixed color', 'fixed'), ('Gradient colors', 'gradient')],
                    'config': config.plugins.AiTranslateS.color_mode
                }),
                ('Fixed Color', 'fixed_color', 'choice', {
                    'title': 'Select Fixed Color',
                    'choices': [
                        ('Yellow', '#ffff00'), ('Green', '#00ff00'), ('Light Blue', '#00aaff'),
                        ('Pink', '#ff00ff'), ('Orange', '#ff8800'), ('Red', '#ff0000'),
                        ('Purple', '#aa00ff'), ('Cyan', '#00ffff')
                    ],
                    'config': config.plugins.AiTranslateS.fixed_color
                }),
                ('Quick Actions', 'quick_actions', 'action', {
                    'title': 'Quick Actions',
                    'callback': self.showQuickActions
                })
            ],
            # Row 2
            [
                ('Groq API Status', 'groq_status', 'status', {}),
                ('Gemini API Status', 'gemini_status', 'status', {}),
                ('Manage Keys', 'manage_keys', 'action', {
                    'title': 'Manage API Keys',
                    'callback': self.openKeyManager
                })
            ],
            # Row 3
            [
                ('Start Overlay', 'start', 'action', {
                    'title': 'Start Live Translation',
                    'callback': self.startOverlay
                }),
                ('Save Settings', 'save', 'action', {
                    'title': 'Save Settings',
                    'callback': self.saveSettings
                }),
                ('Exit', 'exit', 'action', {
                    'title': 'Exit',
                    'callback': self.close
                })
            ]
        ]

        self['title'] = StaticText('AI TranslateS - POPUP SUBMENUS (v2.8)')
        self['col1_header'] = Label('CONFIGURATION')
        self['col2_header'] = Label('APPEARANCE')
        self['col3_header'] = Label('ACTIONS')

        self.cells = []
        for row in range(self.rows):
            row_cells = []
            for col in range(self.cols):
                cell_name = 'cell_{}_{}'.format(row, col)
                self[cell_name] = Label('')
                row_cells.append(cell_name)
            self.cells.append(row_cells)

        self['selection_highlight'] = Label('')
        self['help_text'] = Label('Use ▲▼◀▶ to navigate • Press OK to open popup menu • Edit while watching TV')
        self['key_red'] = Label('Exit')
        self['key_green'] = Label('Save')
        self['key_yellow'] = Label('Start')
        self['key_blue'] = Label('API Keys')

        self['actions'] = ActionMap(['WizardActions', 'SetupActions', 'ColorActions'], {
            'ok': self.activateCurrentCell,
            'cancel': self.close,
            'red': self.close,
            'green': self.saveSettings,
            'yellow': self.startOverlay,
            'blue': self.openKeyManager,
            'up': self.moveUp,
            'down': self.moveDown,
            'left': self.moveLeft,
            'right': self.moveRight
        }, -2)

        self.onLayoutFinish.append(self.updateAllCells)
        self.onLayoutFinish.append(self.updateSelection)

    def updateAllCells(self):
        for row in range(self.rows):
            for col in range(self.cols):
                self.updateCell(row, col)

    def updateCell(self, row, col):
        cell_data = self.grid_content[row][col]
        label = cell_data[0]
        value_type = cell_data[2]

        try:
            if value_type == 'choice':
                config_obj = cell_data[3]['config']
                if config_obj == config.plugins.AiTranslateS.provider:
                    value_map = {'auto': 'Auto', 'groq': 'Groq', 'gemini': 'Gemini'}
                    value = value_map.get(config_obj.value, config_obj.value)
                elif config_obj == config.plugins.AiTranslateS.font_size:
                    value = config_obj.value
                elif config_obj == config.plugins.AiTranslateS.max_words:
                    value = config_obj.value + ' words'
                elif config_obj == config.plugins.AiTranslateS.color_mode:
                    value_map = {'random': 'Random', 'sequential': 'Sequential', 'fixed': 'Fixed', 'gradient': 'Gradient'}
                    value = value_map.get(config_obj.value, config_obj.value)
                elif config_obj == config.plugins.AiTranslateS.fixed_color:
                    color_map = {
                        '#ffff00': 'Yellow', '#00ff00': 'Green', '#00aaff': 'Light Blue',
                        '#ff00ff': 'Pink', '#ff8800': 'Orange', '#ff0000': 'Red',
                        '#aa00ff': 'Purple', '#00ffff': 'Cyan'
                    }
                    value = color_map.get(config_obj.value, config_obj.value)
                else:
                    value = config_obj.value
                display_text = '{}: {}'.format(label, value)
            elif value_type == 'status':
                api_keys = APIKeyManager.get_api_keys()
                if row == 2 and col == 0:
                    key = api_keys['groq']
                    if key:
                        if APIKeyManager.validate_api_key('groq', key):
                            display_text = '✓ Groq: Valid'
                        else:
                            display_text = '✗ Groq: Invalid'
                    else:
                        display_text = '○ Groq: Not set'
                elif row == 2 and col == 1:
                    key = api_keys['gemini']
                    if key:
                        if APIKeyManager.validate_api_key('gemini', key):
                            display_text = '✓ Gemini: Valid'
                        else:
                            display_text = '✗ Gemini: Invalid'
                    else:
                        display_text = '○ Gemini: Not set'
                else:
                    display_text = label
            else:
                display_text = label

            if len(display_text) > 25:
                display_text = display_text[:22] + '...'
            self[self.cells[row][col]].setText(display_text)
        except Exception as e:
            print('[AiTranslateS] Error updating cell:', e)
            self[self.cells[row][col]].setText(label)

    def updateSelection(self):
        base_x = 120
        base_y = 150
        cell_width = 300
        cell_height = 76
        col_spacing = 110
        row_spacing = 10
        x = base_x + self.current_col * (cell_width + col_spacing)
        y = base_y + self.current_row * (cell_height + row_spacing)
        self['selection_highlight'].setPosition(x, y)
        cell_data = self.grid_content[self.current_row][self.current_col]
        self['help_text'].setText('Selected: {} • Press OK to open popup menu'.format(cell_data[0]))

    def moveUp(self):
        if self.current_row > 0:
            self.current_row -= 1
            self.updateSelection()

    def moveDown(self):
        if self.current_row < self.rows - 1:
            self.current_row += 1
            self.updateSelection()

    def moveLeft(self):
        if self.current_col > 0:
            self.current_col -= 1
            self.updateSelection()

    def moveRight(self):
        if self.current_col < self.cols - 1:
            self.current_col += 1
            self.updateSelection()

    def activateCurrentCell(self):
        cell_data = self.grid_content[self.current_row][self.current_col]
        value_type = cell_data[2]
        action_data = cell_data[3]

        if value_type == 'choice':
            self.openChoiceBox(cell_data[0], action_data['title'], action_data['choices'], action_data['config'])
        elif value_type == 'status':
            self.showStatusPopup(cell_data[0], self.current_row, self.current_col)
        elif value_type == 'action':
            callback = action_data.get('callback')
            if callback:
                callback()

    def openChoiceBox(self, cell_label, title, choices, config_obj):
        choice_list = [(choice[0], choice[1]) for choice in choices]
        self.session.openWithCallback(
            lambda choice: self.choiceBoxCallback(choice, cell_label, config_obj),
            ChoiceBox, title=title, list=choice_list
        )

    def choiceBoxCallback(self, result, cell_label, config_obj):
        if result and len(result) >= 1:
            selected_text, selected_value = result
            config_obj.value = selected_value
            config_obj.save()
            self.session.open(MessageBox, '✓ {} set to: {}'.format(cell_label, selected_text), MessageBox.TYPE_INFO, timeout=2)
            self.updateCell(self.current_row, self.current_col)

    def showStatusPopup(self, cell_label, row, col):
        api_keys = APIKeyManager.get_api_keys()
        if row == 2 and col == 0:
            key = api_keys['groq']
            if key:
                if APIKeyManager.validate_api_key('groq', key):
                    masked_key = key[:10] + '...' + key[-5:] if len(key) > 15 else key
                    msg = '✓ Groq API Key is VALID\n\nKey: {}\n\nPress OK to edit'.format(masked_key)
                else:
                    masked = key[:15] + '...' if len(key) > 15 else key
                    msg = '✗ Groq API Key is INVALID\n\nKey: {}\n\nPlease check your key format.\nGroq keys should start with "gsk_"'.format(masked)
            else:
                msg = '○ Groq API Key not set\n\nPress OK to add your Groq API key'
        elif row == 2 and col == 1:
            key = api_keys['gemini']
            if key:
                if APIKeyManager.validate_api_key('gemini', key):
                    masked_key = key[:10] + '...' + key[-5:] if len(key) > 15 else key
                    msg = '✓ Gemini API Key is VALID\n\nKey: {}\n\nPress OK to edit'.format(masked_key)
                else:
                    masked = key[:15] + '...' if len(key) > 15 else key
                    msg = '✗ Gemini API Key is INVALID\n\nKey: {}\n\nPlease check your key format.\nGemini keys should start with "AIza"'.format(masked)
            else:
                msg = '○ Gemini API Key not set\n\nPress OK to add your Gemini API key'
        else:
            msg = 'Status information not available'

        self.session.openWithCallback(
            lambda result: self.handleStatusPopupResult(result, row, col),
            MessageBox, msg, MessageBox.TYPE_INFO, simple=True
        )

    def handleStatusPopupResult(self, result, row, col):
        if result:
            self.openKeyManager()

    def openKeyManager(self):
        self.session.openWithCallback(self.onKeyManagerClosed, APIKeyManagerScreen)

    def onKeyManagerClosed(self, result=None):
        self.updateCell(2, 0)
        self.updateCell(2, 1)

    def showQuickActions(self):
        actions = [
            ('Clear Groq Key', 'clear_groq'),
            ('Clear Gemini Key', 'clear_gemini'),
            ('Reset All Settings', 'reset'),
            ('Check API Status', 'status'),
            ('View Current Settings', 'view_settings'),
            ('Test API Connection', 'test_api')
        ]
        self.session.openWithCallback(self.quickActionCallback, ChoiceBox, title='Quick Actions - Select option:', list=actions)

    def quickActionCallback(self, result):
        if not result or len(result) != 2:
            return
        selected_text, action = result

        if action == 'clear_groq':
            APIKeyManager.write_api_key('groq', '')
            self.session.open(MessageBox, '✓ Groq API key cleared', MessageBox.TYPE_INFO, timeout=2)
        elif action == 'clear_gemini':
            APIKeyManager.write_api_key('gemini', '')
            self.session.open(MessageBox, '✓ Gemini API key cleared', MessageBox.TYPE_INFO, timeout=2)
        elif action == 'reset':
            config.plugins.AiTranslateS.provider.value = 'auto'
            config.plugins.AiTranslateS.font_size.value = '52'
            config.plugins.AiTranslateS.max_words.value = '10'
            config.plugins.AiTranslateS.color_mode.value = 'random'
            config.plugins.AiTranslateS.fixed_color.value = '#ffff00'
            config.plugins.AiTranslateS.save()
            self.session.open(MessageBox, '✓ Settings reset to defaults', MessageBox.TYPE_INFO, timeout=2)
        elif action == 'status':
            keys = APIKeyManager.get_api_keys()
            msg = 'GROQ: {}\n'.format('✓ Valid' if APIKeyManager.validate_api_key('groq', keys['groq']) else '✗ Invalid/Not set')
            msg += 'GEMINI: {}\n\n'.format('✓ Valid' if APIKeyManager.validate_api_key('gemini', keys['gemini']) else '✗ Invalid/Not set')
            msg += 'Provider: {}\n'.format(config.plugins.AiTranslateS.provider.value)
            msg += 'Font Size: {}\n'.format(config.plugins.AiTranslateS.font_size.value)
            msg += 'Max Words: {}\n'.format(config.plugins.AiTranslateS.max_words.value)
            msg += 'Color Mode: {}'.format(config.plugins.AiTranslateS.color_mode.value)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=5)
        elif action == 'view_settings':
            settings = 'Current Settings:\n\n'
            settings += 'Provider: {}\n'.format(config.plugins.AiTranslateS.provider.value)
            settings += 'Font Size: {}\n'.format(config.plugins.AiTranslateS.font_size.value)
            settings += 'Max Words: {}\n'.format(config.plugins.AiTranslateS.max_words.value)
            settings += 'Color Mode: {}\n'.format(config.plugins.AiTranslateS.color_mode.value)
            settings += 'Fixed Color: {}'.format(config.plugins.AiTranslateS.fixed_color.value)
            self.session.open(MessageBox, settings, MessageBox.TYPE_INFO, timeout=5)
        elif action == 'test_api':
            self.testAPIConnection()

        self.updateCell(2, 0)
        self.updateCell(2, 1)
        self.updateAllCells()

    def testAPIConnection(self):
        provider = config.plugins.AiTranslateS.provider.value
        keys = APIKeyManager.get_api_keys()
        if provider == 'groq' or provider == 'auto':
            if keys['groq'] and APIKeyManager.validate_api_key('groq', keys['groq']):
                self.session.open(MessageBox, 'Groq API key format is valid.\nConnection test would be performed here.', MessageBox.TYPE_INFO, timeout=3)
            else:
                self.session.open(MessageBox, 'Groq API key is invalid or not set', MessageBox.TYPE_ERROR)
        elif provider == 'gemini':
            if keys['gemini'] and APIKeyManager.validate_api_key('gemini', keys['gemini']):
                self.session.open(MessageBox, 'Gemini API key format is valid.\nConnection test would be performed here.', MessageBox.TYPE_INFO, timeout=3)
            else:
                self.session.open(MessageBox, 'Gemini API key is invalid or not set', MessageBox.TYPE_ERROR)

    def saveSettings(self):
        config.plugins.AiTranslateS.save()
        self.session.open(MessageBox, '✓ Settings saved successfully!', MessageBox.TYPE_INFO, timeout=2)

    def startOverlay(self):
        api_keys = APIKeyManager.get_api_keys()
        provider = config.plugins.AiTranslateS.provider.value

        if provider == 'groq' and not (api_keys['groq'] and APIKeyManager.validate_api_key('groq', api_keys['groq'])):
            self.session.open(MessageBox, 'You must add a valid Groq API key first', MessageBox.TYPE_ERROR)
        elif provider == 'gemini' and not (api_keys['gemini'] and APIKeyManager.validate_api_key('gemini', api_keys['gemini'])):
            self.session.open(MessageBox, 'You must add a valid Gemini API key first', MessageBox.TYPE_ERROR)
        elif provider == 'auto' and not api_keys['groq'] and not api_keys['gemini']:
            self.session.open(MessageBox, 'You must add at least one API key', MessageBox.TYPE_ERROR)
        else:
            self.session.open(MessageBox, 'Starting AI TranslateS...', MessageBox.TYPE_INFO, timeout=1)
            self.session.open(AiTranslateOverlay)

class APIKeyManagerScreen(Screen):
    skin = '''
    <screen name="APIKeyManagerScreen" position="460,308" size="1050,486" title="API Key Management" backgroundColor="#101010" borderWidth="1" borderColor="#10808080">
        <widget name="groq_label" position="20,20" size="1013,34" font="Regular;26" halign="left" valign="center" foregroundColor="#ffffff" />
        <widget name="groq_key" position="20,65" size="1013,66" font="Regular;26" halign="left" valign="center" backgroundColor="#303030" foregroundColor="#ffff00" />
        <widget name="gemini_label" position="20,140" size="1013,34" font="Regular;26" halign="left" valign="center" foregroundColor="#ffffff" />
        <widget name="gemini_key" position="20,185" size="1013,97" font="Regular;26" halign="left" valign="center" backgroundColor="#303030" foregroundColor="#ffff00" />
        <widget name="info" position="20,292" size="1013,114" font="Regular;26" halign="left" valign="center" foregroundColor="#00ff00" />
        <widget name="key_green" position="187,425" size="185,40" zPosition="1" cornerRadius="10" font="Regular;22" halign="center" valign="center" backgroundColor="#1f771f" foregroundColor="white" />
        <widget name="key_red" position="432,425" size="180,40" zPosition="1" cornerRadius="10" font="Regular;22" halign="center" valign="center" backgroundColor="#9f1313" foregroundColor="white" />
        <widget name="key_blue" position="673,425" size="185,40" zPosition="1" cornerRadius="10" font="Regular;22" halign="center" valign="center" backgroundColor="#1818b4" foregroundColor="white" />
    </screen>
    '''

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self['groq_label'] = Label('Groq API key :')
        self['groq_key'] = Label('')
        self['gemini_label'] = Label('Gemini API key :')
        self['gemini_key'] = Label('')
        self['info'] = Label('')
        self['key_green'] = Label('Edit')
        self['key_red'] = Label('Cancel')
        self['key_blue'] = Label('Clear all')

        self.groq_key = ''
        self.gemini_key = ''

        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {
            'cancel': self.close,
            'red': self.close,
            'green': self.editKeys,
            'blue': self.clearKeys,
            'ok': self.editKeys
        }, -2)

        self.onLayoutFinish.append(self.loadKeys)

    def loadKeys(self):
        self.groq_key = APIKeyManager.read_api_key('groq')
        self.gemini_key = APIKeyManager.read_api_key('gemini')
        self['groq_key'].setText(self.groq_key if self.groq_key else '(not set)')
        self['gemini_key'].setText(self.gemini_key if self.gemini_key else '(not set)')

        info_text = ''
        if self.groq_key:
            if APIKeyManager.validate_api_key('groq', self.groq_key):
                info_text += '✓ Groq API key is valid\n'
            else:
                info_text += '✗ Groq API key is invalid\n'
        if self.gemini_key:
            if APIKeyManager.validate_api_key('gemini', self.gemini_key):
                info_text += '✓ Gemini API key is valid\n'
            else:
                info_text += '✗ Gemini API key is invalid\n'
        if not info_text:
            info_text = 'Enter your API keys:\n\n'
            info_text += '- Groq API: starts with "gsk_..."\n'
            info_text += '- Gemini API: starts with "AIza..."\n\n'
            info_text += 'Keys will be saved to:\n'
            info_text += '  {}\n'.format(API_KEY_PATHS['groq'])
            info_text += '  {}'.format(API_KEY_PATHS['gemini'])
        self['info'].setText(info_text)

    def editKeys(self):
        self.session.openWithCallback(self.onGroqKeyEntered, VirtualKeyBoard, title='Enter Groq API key', text=self.groq_key)

    def onGroqKeyEntered(self, key):
        if key is not None:
            self.groq_key = key
            self.session.openWithCallback(self.onGeminiKeyEntered, VirtualKeyBoard, title='Enter Gemini API key', text=self.gemini_key)

    def onGeminiKeyEntered(self, key):
        if key is not None:
            self.gemini_key = key
            APIKeyManager.write_api_key('groq', self.groq_key)
            APIKeyManager.write_api_key('gemini', self.gemini_key)
            self.loadKeys()
            self.close()

    def clearKeys(self):
        self.session.openWithCallback(self.confirmClear, MessageBox, 'Do you want to clear all API keys?', MessageBox.TYPE_YESNO)

    def confirmClear(self, result):
        if result:
            APIKeyManager.write_api_key('groq', '')
            APIKeyManager.write_api_key('gemini', '')
            self.groq_key = ''
            self.gemini_key = ''
            self.loadKeys()

def main(session, **kwargs):
    session.open(AiTranslateGridSettings)

def menuHook(menuid):
    if menuid == 'extensions':
        return [('AI TranslateS v2.8 (Popup Submenus + Shadow Toggle)', main, 'ai_translates_popup_shadow', 46)]
    return []

def Plugins(**kwargs):
    descplug = 'Display real-time translation with popup submenus and shadow toggle (0 key)'
    return [
        PluginDescriptor(name='AI TranslateS v2.8', description=descplug, where=PluginDescriptor.WHERE_EXTENSIONSMENU, icon='plugin.png', fnc=menuHook),
        PluginDescriptor(name='AI TranslateS v2.8', description=descplug, where=PluginDescriptor.WHERE_PLUGINMENU, icon='plugin.png', fnc=main),
        PluginDescriptor(name='AI TranslateS v2.8', description=descplug, where=PluginDescriptor.WHERE_MOVIELIST, icon='plugin.png', fnc=main),
        PluginDescriptor(name='AI TranslateS v2.8', description=descplug, where=PluginDescriptor.WHERE_MAINMENU, icon='plugin.png', fnc=main)
    ]